<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

# Project Notes
- Chat overlays use the shared accessible Dialog and controls use Button variants so keyboard focus, dismissal, and touch targets stay consistent.

- Drawing auto-replies match user-selected categories locally through the shared auto-replies helper, not image recognition, to keep drawings private and preserve existing text rules.
- Auto-replies start empty: never seed premade rules, and drop any legacy seeded rule ids on load so removed defaults don't reappear.

- Note to Self uses component state by default, with explicit opt-in browser-only persistence through the shared chat-storage helper; no backend is connected.
- Speech-to-text runs fully on-device via @huggingface/transformers (Whisper tiny.en, q8) — dynamically imported client-side only in src/lib/whisper.ts. Never switch to the Web Speech API: it sends audio to browser-vendor servers, which violates the app's privacy guarantee. The mic button is disabled when local processing is unavailable (non-secure context, no WebAssembly/MediaRecorder/getUserMedia).
- Storage keys: "self-messages" (messages, scheduled notes and photo only with "self-save-messages" consent), "self-rules" (persists intentionally). Disabling consent deletes saved chat data; due scheduled notes are delivered once on reopening.
- Dev server runs at http://localhost:8080; Playwright pattern: click input → keyboard.type(delay=20) → keyboard.press("Enter") for React controlled inputs.
