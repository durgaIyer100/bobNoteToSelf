import { createFileRoute, Link } from "@tanstack/react-router";
import chatScreenshot from "@/assets/chat-interface.png.asset.json";
import repliesScreenshot from "@/assets/auto-replies.png.asset.json";
import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Note to Self — Check in on yourself" },
      { name: "description", content: "Message yourself, schedule kind notes, speak or draw privately, with optional saving on your device." },
      { property: "og:title", content: "Note to Self — Check in on yourself" },
      { property: "og:description", content: "Message yourself, schedule kind notes, speak or draw privately, with optional saving on your device." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Home,
});

function Home() {
  return (
    <div className="font-lexend min-h-screen bg-background px-4 py-10 sm:px-6 sm:py-16">
      <div className="mx-auto max-w-4xl text-center">
        <h1 className="text-4xl font-semibold text-foreground">Note to Self</h1>
        <p className="mt-3 text-muted-foreground">Be the person you want to talk to. Your notes stay on your device, never sent to us.</p>
        <Button asChild size="lg" className="mt-8 min-h-11"><Link to="/chat">Open Note to Self<ArrowRight aria-hidden="true" /></Link></Button>
        <h2 className="mt-16 text-xl font-semibold text-foreground">How it works</h2>
        <div className="mt-6 grid items-stretch gap-6 md:grid-cols-2">
            <article className="min-w-0 rounded-2xl border border-border bg-card p-5 sm:p-6">
              <h3 className="mb-4 text-lg font-semibold">Note to Self</h3>
              <img src={chatScreenshot.url} alt="Actual Note to Self chat with messages and the bottom toolbar" loading="lazy" className="h-96 w-full rounded-lg border bg-chat-background object-contain" />
              <ol className="mt-5 space-y-3 text-left text-sm leading-relaxed text-muted-foreground list-decimal pl-5">
                <li>Type a message — or add your own auto-replies first (see Auto-Replies below) so a keyword sends yourself a word back.</li>
                <li>Pick a time with the clock to schedule a message to your future self (green bubbles). With saving off, keep this tab open; with saving on, overdue notes arrive when you reopen it.</li>
                <li>Tap the mic to speak — your words become text right on your device. If your browser can't transcribe locally, the mic stays off.</li>
                <li>Tap Draw to sketch a message, and schedule it too if you like.</li>
              </ol>
            </article>
            <article className="min-w-0 rounded-2xl border border-border bg-card p-5 sm:p-6">
              <h3 className="mb-4 text-lg font-semibold">Auto-Replies</h3>
              <img src={repliesScreenshot.url} alt="Actual Auto-Replies panel with text and drawing types and a custom message" loading="lazy" className="h-96 w-full rounded-lg border bg-background object-contain" />
              <ol className="mt-5 space-y-3 text-left text-sm leading-relaxed text-muted-foreground list-decimal pl-5">
                <li>Open Note to Self and tap the speech-bubble icon in the bottom bar to open Auto-Replies.</li>
                <li>Choose <strong>Text</strong> for keyword replies or <strong>Drawing</strong> for replies to a drawing type you select.</li>
                <li>Enter keywords or drawing types, separated by commas, then write the message you want to receive.</li>
                <li>Tap <strong>Add auto-reply</strong>, then <strong>Save</strong>. Send a matching text message, or choose that type when sending a drawing, to receive your reply.</li>
              </ol>
            </article>
        </div>
        <h2 className="mt-16 text-xl font-semibold text-foreground">Your privacy</h2>
        <div className="mt-4 border-t py-6 text-left text-sm leading-relaxed space-y-3">
          <p className="text-foreground"><strong>Close the tab and it's gone — unless you choose to save.</strong> By default, your messages, drawings, scheduled notes and profile photo disappear when you close or reload the tab. Turn on “Save messages on this device” to keep them in this browser. Turning it off deletes the saved copy, while your current chat stays until you leave.</p>
          <ul className="space-y-1 text-muted-foreground list-disc pl-5">
            <li>Messages, drawings, profile photos and audio are never sent to any service. Optional saved notes stay only in this browser, not in an account or on our servers. Anyone using this browser can access saved notes; clearing browser data removes them.</li>
            <li>Your voice is transcribed entirely on your own device. If your browser can't process it locally, the microphone is disabled.</li>
            <li>The first use downloads the voice model to your browser (that's the only network contact, never your audio), then it transcribes locally.</li>
            <li>Your auto-reply keywords and reply text are kept in this browser's storage on your device, independently of the message-saving toggle — nothing leaves it.</li>
            <li>No accounts, no tracking, no analytics.</li>
          </ul>
        </div>
      </div>
    </div>
  );
}
