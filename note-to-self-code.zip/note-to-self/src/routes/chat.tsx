import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { speechSupported, transcribeBlob } from "@/lib/whisper";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
import { Home, MessageCircle, Camera, Clock, Mic, Pencil, Send, Settings, Square, Trash2, X } from "lucide-react";
import { deliverDue, emptyChat, loadChat, saveChat, type Msg } from "@/lib/chat-storage";
import { matchReply, type Rule } from "@/lib/auto-replies";

export const Route = createFileRoute("/chat")({
  head: () => ({
    meta: [
      { title: "Chat — Note to Self" },
      { name: "description", content: "Send, schedule, speak or draw messages to yourself." },
      { property: "og:title", content: "Chat — Note to Self" },
      { property: "og:description", content: "Send, schedule, speak or draw messages to yourself." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Chat,
});

const RULE_KEY = "self-rules";


function Chat() {
  const [data, setData] = useState(emptyChat);
  const [saveEnabled, setSaveEnabled] = useState(false);
  const [ready, setReady] = useState(false);
  const [storageError, setStorageError] = useState("");
  const [showSettings, setShowSettings] = useState(false);
  const [showSchedule, setShowSchedule] = useState(false);
  const photoInput = useRef<HTMLInputElement>(null);
  const msgs = data.messages;
  const pending = data.scheduled.length;
  const setMsgs = (update: Msg[] | ((messages: Msg[]) => Msg[])) => setData((p) => ({ ...p, messages: typeof update === "function" ? update(p.messages) : update }));
  const [rules, setRules] = useState<Rule[]>([]);
  const [text, setText] = useState("");
  const [when, setWhen] = useState("");
  const [showRules, setShowRules] = useState(false);
  const [showDraw, setShowDraw] = useState(false);
  const [micState, setMicState] = useState<"idle" | "loading" | "recording" | "transcribing">("idle");
  const [micSupported, setMicSupported] = useState(false);
  const recRef = useRef<MediaRecorder | null>(null);
  const endRef = useRef<HTMLDivElement>(null);
  const timers = useRef<number[]>([]);
  const chunks = useRef<Blob[]>([]);

  useEffect(() => {
    try {
      const saved = loadChat(localStorage);
      setSaveEnabled(saved.enabled);
      setData(deliverDue(saved.data, Date.now()));
    } catch { setStorageError("Browser saving is unavailable. This chat will disappear when you leave."); }
    setReady(true);
    setMicSupported(speechSupported());
    try {
      const saved = localStorage.getItem(RULE_KEY);
      if (saved !== null) {
        const parsed: Rule[] = JSON.parse(saved);
        const kept = parsed.filter((r) => r.id !== "seed-sad" && r.id !== "seed-happy");
        if (kept.length !== parsed.length) localStorage.setItem(RULE_KEY, JSON.stringify(kept));
        setRules(kept);
      }
    } catch {}
    return () => {
      timers.current.forEach(clearTimeout);
      if (recRef.current?.state === "recording") recRef.current.stop();
    };
  }, []);
  useEffect(() => { endRef.current?.scrollIntoView({ behavior: "smooth" }); }, [msgs]);
  useEffect(() => {
    if (!ready) return;
    try { saveChat(localStorage, saveEnabled, data); }
    catch {
      setStorageError("Could not save on this device. Browser storage may be full or blocked; this chat may disappear when you leave.");
      setSaveEnabled(false);
      try { saveChat(localStorage, false, emptyChat()); } catch {}
    }
  }, [data, saveEnabled, ready]);
  useEffect(() => {
    const timer = window.setInterval(() => setData((p) => deliverDue(p, Date.now())), 1000);
    return () => window.clearInterval(timer);
  }, []);

  const changeSaving = (enabled: boolean) => {
    try {
      saveChat(localStorage, enabled, data);
      setSaveEnabled(enabled);
      setStorageError("");
    } catch { setStorageError("Browser saving is unavailable. Your current chat is still here; saved data could not be updated."); }
  };
  const uploadPhoto = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    event.target.value = "";
    if (!file) return;
    if (!file.type.startsWith("image/") || file.type === "image/svg+xml") return alert("Choose a JPG, PNG, GIF or WebP photo.");
    if (file.size > 20 * 1024 * 1024) return alert("Choose a photo smaller than 20 MB.");
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result !== "string") return;
      const image = new Image();
      image.onload = () => {
        const canvas = document.createElement("canvas");
        canvas.width = 256; canvas.height = 256;
        const context = canvas.getContext("2d");
        if (!context) return;
        const side = Math.min(image.width, image.height);
        context.drawImage(image, (image.width - side) / 2, (image.height - side) / 2, side, side, 0, 0, 256, 256);
        setData((p) => ({ ...p, photo: canvas.toDataURL("image/jpeg", 0.85) }));
      };
      image.onerror = () => alert("This photo could not be opened. Try a JPG or PNG.");
      image.src = reader.result;
    };
    reader.readAsDataURL(file);
  };
  const avatar = (large = false) => (
    <span className={`inline-flex shrink-0 items-center justify-center overflow-hidden rounded-full bg-chat-avatar ${large ? "size-16 text-4xl" : "size-9 text-2xl"}`}>
      {data.photo ? <img src={data.photo} alt="Your profile photo" className="size-full object-cover" /> : <span aria-label="Smiley profile">🙂</span>}
    </span>
  );

  const push = (m: Omit<Msg, "id" | "at">) => setMsgs((p) => [...p, { ...m, id: crypto.randomUUID(), at: Date.now() }]);
  const saveRules = (r: Rule[]) => { setRules(r); localStorage.setItem(RULE_KEY, JSON.stringify(r)); };

  const schedule = (m: Omit<Msg, "id" | "at">, at: string) => {
    const delay = new Date(at).getTime() - Date.now();
    if (!(delay > 0)) return false;
    setData((p) => ({ ...p, scheduled: [...p.scheduled, { ...m, id: crypto.randomUUID(), at: new Date(at).getTime(), scheduled: true }] }));
    return true;
  };

  const send = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = text.trim();
    if (!trimmed) return;
    if (when) {
      if (!schedule({ text: trimmed }, when)) return alert("Pick a time in the future.");
      setText(""); setWhen(""); return;
    }
    push({ text: trimmed });
    setText("");
    const rule = matchReply(rules, trimmed, "text");
    if (rule) timers.current.push(window.setTimeout(() => push({ text: rule.message, auto: true }), 700));
  };

  const toggleMic = async () => {
    if (micState === "recording") { recRef.current?.stop(); return; }
    if (micState !== "idle") return;
    setMicState("loading");
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const rec = new MediaRecorder(stream);
      chunks.current = [];
      rec.ondataavailable = (e) => { if (e.data.size) chunks.current.push(e.data); };
      rec.onstop = async () => {
        stream.getTracks().forEach((t) => t.stop());
        setMicState("transcribing");
        try {
          const transcript = await transcribeBlob(new Blob(chunks.current, { type: rec.mimeType || "audio/webm" }));
          if (transcript) setText((p) => (p ? p + " " : "") + transcript);
        } catch (e) {
          console.error("Voice transcription failed:", e);
          alert("Voice transcription failed on this device. Try again.");
        }
        setMicState("idle");
      };
      recRef.current = rec;
      rec.start();
      setMicState("recording");
    } catch {
      setMicState("idle");
      alert("Microphone access is needed to speak. Nothing is recorded or sent anywhere.");
    }
  };

  const bubble = (m: Msg) => m.scheduled || m.auto
    ? "rounded-bl-sm bg-chat-reply text-chat-ink"
    : "rounded-br-sm bg-chat-user text-chat-ink";

  return (
    <div className="flex h-dvh flex-col bg-chat-background text-chat-ink">
      <header className="relative mx-auto flex w-full max-w-3xl items-center justify-between px-4 py-4 sm:px-8">
        <Button asChild variant="ghost" size="icon" className="text-chat-tool" title="Home"><Link to="/" aria-label="Home"><Home /></Link></Button>
        <div className="flex flex-col items-center gap-2">
          <Button variant="ghost" type="button" className="relative h-auto rounded-full p-0" onClick={() => photoInput.current?.click()} title="Upload profile photo" aria-label="Upload profile photo">
            {avatar(true)}<Camera className="absolute bottom-0 right-0 rounded-full bg-background p-0.5 text-chat-tool" />
          </Button>
          <h1 className="text-lg font-semibold">Note to Self</h1>
        </div>
        <Button variant="ghost" size="icon" className="text-chat-tool" title="Chat settings" aria-label="Chat settings" onClick={() => setShowSettings(!showSettings)}><Settings /></Button>
        <input ref={photoInput} type="file" accept="image/jpeg,image/png,image/webp,image/gif" onChange={uploadPhoto} className="hidden" aria-label="Choose profile photo" />
      </header>
      <div className="mx-auto flex w-full max-w-3xl flex-wrap items-center justify-center gap-x-3 gap-y-1 px-4 pb-3 text-xs text-muted-foreground">
        <label htmlFor="save-messages" className="flex cursor-pointer items-center gap-2"><Switch id="save-messages" checked={saveEnabled} onCheckedChange={changeSaving} disabled={!ready} />Save messages on this device</label>
        {pending > 0 && <span>{pending} scheduled</span>}
      </div>
      <p className="px-4 text-center text-xs text-muted-foreground">{saveEnabled ? "Saved only in this browser. Overdue notes arrive when you reopen it." : "Close or reload this tab and your messages disappear."}</p>
      {storageError && <p role="alert" className="px-4 pt-2 text-center text-sm text-destructive">{storageError}</p>}
      {showSettings && <div className="mx-auto flex w-full max-w-3xl flex-wrap justify-center gap-2 border-b p-3">
        <Button variant="ghost" size="sm" onClick={() => { if (confirm("Clear all messages and scheduled notes?")) { setMsgs([]); setData((p) => ({ ...p, messages: [], scheduled: [] })); timers.current.forEach(clearTimeout); timers.current = []; } }}><Trash2 />Clear chat</Button>
        {data.photo && <Button variant="ghost" size="sm" onClick={() => setData((p) => ({ ...p, photo: "" }))}><X />Remove photo</Button>}
      </div>}
      <main className="flex-1 overflow-y-auto px-4 py-6 sm:px-8">
        <div className="mx-auto max-w-2xl space-y-5">
          {msgs.length === 0 && <div className="mt-12 text-center text-muted-foreground"><span className="text-4xl" aria-hidden="true">🙂</span><p className="mt-3">A little space for you.</p></div>}
          {msgs.map((m) => (
            <div key={m.id} className={`flex items-start gap-2 ${m.auto || m.scheduled ? "justify-start" : "justify-end"} group`}>
              {(m.auto || m.scheduled) && avatar()}
              <div className={`min-w-0 max-w-[75%] rounded-3xl px-4 py-3 ${bubble(m)}`}>
                {m.image && <img src={m.image} alt="Drawing" className="max-w-full rounded-lg bg-background" />}
                {m.text && <p className="whitespace-pre-wrap break-words">{m.text}</p>}
                <div className="mt-1 flex flex-wrap items-center justify-end gap-2 text-xs opacity-70">
                  {m.auto && <span>auto-reply from you</span>}
                  {m.scheduled && <span>scheduled from you</span>}
                  <Button variant="ghost" size="icon" title="Delete message" aria-label="Delete message" onClick={() => setMsgs((p) => p.filter((x) => x.id !== m.id))} className="size-11 sm:opacity-0 sm:group-hover:opacity-100 focus:opacity-100"><Trash2 /></Button>
                  <span>{new Date(m.at).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}</span>
                </div>
              </div>
              {!m.auto && !m.scheduled && avatar()}
            </div>
          ))}
          <div ref={endRef} />
        </div>
      </main>
      <form onSubmit={send} className="px-4 pb-6 pt-3 sm:px-8">
        <div className="mx-auto max-w-2xl">
          {(showSchedule || when) && <div className="mb-3 flex flex-wrap items-center justify-center gap-2">
            <label htmlFor="schedule-time" className="text-sm">Schedule for</label>
            <input id="schedule-time" type="datetime-local" value={when} onChange={(e) => setWhen(e.target.value)} title="Schedule (optional)" className="min-w-0 max-w-full rounded-lg border bg-background px-3 py-2 text-sm text-foreground" />
            <Button type="button" variant="ghost" size="icon" aria-label="Cancel scheduling" title="Cancel scheduling" onClick={() => { setWhen(""); setShowSchedule(false); }}><X /></Button>
          </div>}
          <div className="flex items-center gap-2">
            <Button type="button" variant="ghost" size="icon" onClick={toggleMic} disabled={!micSupported || micState === "transcribing" || micState === "loading"}
              aria-label={micState === "recording" ? "Stop recording" : "Speak a message"}
              title={micSupported ? "Speak — transcribed on your device, your voice never leaves it" : "Microphone disabled: local transcription is unavailable; your voice is never sent anywhere"}
              className={`size-11 shrink-0 rounded-full ${micState === "recording" ? "bg-destructive text-destructive-foreground" : "bg-chat-avatar text-chat-tool"}`}>
              {micState === "recording" ? <Square /> : <Mic />}
            </Button>
            <input value={text} onChange={(e) => setText(e.target.value)} aria-label="Message yourself" placeholder={micState === "recording" ? "Listening…" : "Message yourself…"} className="h-11 min-w-0 flex-1 rounded-full border-2 bg-transparent px-4 text-foreground outline-none focus:ring-2 focus:ring-ring" />
            <Button type="submit" size="icon" aria-label={when ? "Schedule message" : "Send message"} title={when ? "Schedule message" : "Send message"} className="size-11 shrink-0 rounded-full bg-chat-tool text-primary-foreground" disabled={!text.trim()}><Send /></Button>
          </div>
          <div className="mt-2 flex items-start justify-center gap-2 text-chat-tool">
            <Button type="button" variant="ghost" className="h-auto w-auto flex-col items-center gap-0.5 rounded-lg px-3 py-1.5" title="Auto-Replies" aria-label="Auto-Replies" onClick={() => setShowRules(true)}><MessageCircle /><span className="text-xs leading-none">Auto-Replies</span></Button>
            <Button type="button" variant="ghost" className="h-auto w-auto flex-col items-center gap-0.5 rounded-lg px-3 py-1.5" title="Draw a message" aria-label="Draw a message" onClick={() => setShowDraw(true)}><Pencil /><span className="text-xs leading-none">Draw</span></Button>
            <Button type="button" variant="ghost" className="h-auto w-auto flex-col items-center gap-0.5 rounded-lg px-3 py-1.5" title="Schedule a message" aria-label="Schedule a message" onClick={() => setShowSchedule(!showSchedule)}><Clock /><span className="text-xs leading-none">Schedule</span></Button>
            {micState !== "idle" && <span role="status" className="text-xs text-muted-foreground">{micState === "loading" ? "Opening microphone…" : micState === "recording" ? "Listening…" : "Transcribing on your device…"}</span>}
          </div>
        </div>
      </form>
      {showRules && <RulesPanel rules={rules} onClose={() => setShowRules(false)} onSave={saveRules} />}
      {showDraw && (
        <DrawPanel categories={[...new Set(rules.filter((r) => r.type === "drawing").flatMap((r) => r.keywords))]} onClose={() => setShowDraw(false)} onSend={(image, at, category) => {
          if (at) { if (!schedule({ text: "", image }, at)) return alert("Pick a time in the future."); }
          else push({ text: "", image });
          const rule = matchReply(rules, category, "drawing");
          if (rule) {
            if (at) schedule({ text: rule.message, auto: true }, at);
            else timers.current.push(window.setTimeout(() => push({ text: rule.message, auto: true }), 700));
          }
          setShowDraw(false);
        }} />
      )}
    </div>
  );
}

function DrawPanel({ categories, onClose, onSend }: { categories: string[]; onClose: () => void; onSend: (img: string, at: string, category: string) => void }) {
  const ref = useRef<HTMLCanvasElement>(null);
  const drawing = useRef(false);
  const [at, setAt] = useState("");
  const [category, setCategory] = useState("");
  const ctx = () => ref.current?.getContext("2d");
  const pos = (e: React.PointerEvent): [number, number] => { const r = ref.current?.getBoundingClientRect(); if (!r) return [0, 0]; return [(e.clientX - r.left) * (400 / r.width), (e.clientY - r.top) * (300 / r.height)]; };
  const clear = () => { const c = ctx(); if (!c) return; c.fillStyle = "#fff"; c.fillRect(0, 0, 400, 300); };
  useEffect(clear, []);

  return (
    <Dialog open onOpenChange={(open) => { if (!open) onClose(); }}>
      <DialogContent aria-describedby={undefined} className="w-[calc(100%-2rem)] max-h-[85dvh] overflow-y-auto rounded-lg gap-0">
        <DialogTitle className="mb-3 pr-10 text-lg font-semibold text-foreground">Draw a message</DialogTitle>
        <canvas ref={ref} width={400} height={300} className="w-full touch-none rounded-lg border"
          onPointerDown={(e) => { drawing.current = true; const [x, y] = pos(e); const c = ctx(); if (!c) return; c.strokeStyle = "#222"; c.lineWidth = 3; c.lineCap = "round"; c.beginPath(); c.moveTo(x, y); }}
          onPointerMove={(e) => { if (!drawing.current) return; const [x, y] = pos(e); ctx()?.lineTo(x, y); ctx()?.stroke(); }}
          onPointerUp={() => (drawing.current = false)} onPointerLeave={() => (drawing.current = false)} />
        <label htmlFor="drawing-category" className="mt-3 block text-sm font-medium text-foreground">Drawing type (optional)</label>
        <select id="drawing-category" value={category} onChange={(e) => setCategory(e.target.value)} className="mt-1 w-full rounded-lg border bg-background px-3 py-2 text-foreground">
          <option value="">No auto-reply</option>
          {categories.map((item) => <option key={item} value={item}>{item}</option>)}
        </select>
        <label htmlFor="drawing-schedule" className="mt-3 block text-sm font-medium text-foreground">Schedule (optional)</label>
        <input id="drawing-schedule" type="datetime-local" value={at} onChange={(e) => setAt(e.target.value)} className="mt-1 min-w-0 w-full rounded-lg border bg-background px-3 py-2 text-foreground" />
        <div className="mt-4 flex justify-between gap-2">
          <Button variant="outline" onClick={clear}><Trash2 />Clear</Button>
          <div className="flex gap-2">
            <Button variant="outline" onClick={onClose}>Cancel</Button>
            <Button onClick={() => ref.current && onSend(ref.current.toDataURL("image/png"), at, category)} className="rounded-full bg-primary px-4 py-2 text-sm text-primary-foreground">{at ? "Schedule" : "Send"}</Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function RulesPanel({ rules, onClose, onSave }: { rules: Rule[]; onClose: () => void; onSave: (r: Rule[]) => void }) {
  const [list, setList] = useState<Rule[]>(rules);
  const [keywords, setKeywords] = useState("");
  const [message, setMessage] = useState("");
  const [type, setType] = useState<"text" | "drawing">("text");

  const add = () => {
    const kws = keywords.split(",").map((k) => k.trim()).filter(Boolean);
    if (!kws.length || !message.trim()) return;
    setList([...list, { id: crypto.randomUUID(), keywords: kws, message: message.trim(), type }]);
    setKeywords(""); setMessage("");
  };

  return (
    <Dialog open onOpenChange={(open) => { if (!open) onClose(); }}>
      <DialogContent aria-describedby={undefined} className="w-[calc(100%-2rem)] max-h-[85dvh] overflow-y-auto rounded-lg gap-0">
        <DialogTitle className="mb-4 pr-10 text-lg font-semibold text-foreground">Auto-replies</DialogTitle>
        <div className="space-y-3 mb-4">
          {list.length === 0 && <p className="text-sm text-muted-foreground italic">No auto-replies yet.</p>}
          {list.map((r) => (
            <div key={r.id} className="rounded-xl border p-3">
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0"><span className="text-xs text-muted-foreground">{r.type === "drawing" ? "Drawing" : "Text"}</span><p className="text-sm text-foreground whitespace-pre-wrap break-words">{r.message}</p></div>
                <Button variant="ghost" size="icon" title="Delete auto-reply" aria-label="Delete auto-reply" onClick={() => setList(list.filter((x) => x.id !== r.id))} className="text-muted-foreground hover:text-destructive shrink-0"><Trash2 /></Button>
              </div>
              <div className="mt-2 flex flex-wrap gap-1">
                {r.keywords.map((k, i) => <span key={i} className="rounded-full bg-muted px-2 py-0.5 text-xs text-muted-foreground">{k}</span>)}
              </div>
            </div>
          ))}
        </div>
        <div className="space-y-2 border-t pt-4">
          <div className="flex gap-2" role="group" aria-label="Reply trigger">
            <Button variant={type === "text" ? "default" : "outline"} aria-pressed={type === "text"} onClick={() => setType("text")}><MessageCircle />Text</Button>
            <Button variant={type === "drawing" ? "default" : "outline"} aria-pressed={type === "drawing"} onClick={() => setType("drawing")}><Pencil />Drawing</Button>
          </div>
          <label htmlFor="reply-keywords" className="block text-sm font-medium text-foreground">{type === "drawing" ? "Drawing category (comma-separated)" : "Keywords (comma-separated)"}</label>
          <input id="reply-keywords" value={keywords} onChange={(e) => setKeywords(e.target.value)} placeholder={type === "drawing" ? "heart, sad face, sunshine" : "sad, don't know what to do"}
            className="w-full rounded-lg border bg-background px-3 py-2 text-foreground outline-none focus:ring-2 focus:ring-ring" />
          <label htmlFor="reply-message" className="block text-sm font-medium text-foreground">Message to send</label>
          <textarea id="reply-message" value={message} onChange={(e) => setMessage(e.target.value)} rows={3} placeholder="ex: You got this. Keep going and always breathe."
            className="w-full resize-none rounded-lg border bg-background px-3 py-2 text-foreground outline-none focus:ring-2 focus:ring-ring" />
          <Button onClick={add} className="rounded-full bg-primary px-4 py-2 text-sm text-primary-foreground disabled:opacity-50" disabled={!keywords.trim() || !message.trim()}>Add auto-reply</Button>
        </div>
        <div className="mt-4 flex justify-end gap-2">
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button onClick={() => { onSave(list); onClose(); }} className="rounded-full bg-primary px-4 py-2 text-sm text-primary-foreground">Save</Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
