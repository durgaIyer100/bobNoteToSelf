import { beforeEach, describe, expect, it } from "vitest";
import { deliverDue, emptyChat, loadChat, saveChat } from "@/lib/chat-storage";

describe("Private browser saving", () => {
  beforeEach(() => localStorage.clear());
  const data = { messages: [{ id: "note", text: "Hello future me", at: 10 }], scheduled: [{ id: "drawing", text: "", image: "data:image/png;base64,abc", at: 100 }], photo: "data:image/png;base64,photo" };
  it("does not save messages unless explicitly enabled", () => {
    saveChat(localStorage, false, data);
    expect(localStorage.getItem("self-messages")).toBeNull();
    expect(loadChat(localStorage)).toEqual({ enabled: false, data: emptyChat() });
  });
  it("restores messages, scheduled drawings and photo after opting in", () => {
    saveChat(localStorage, true, data);
    expect(loadChat(localStorage)).toEqual({ enabled: true, data });
  });
  it("removes previously saved information when switched off", () => {
    saveChat(localStorage, true, data);
    saveChat(localStorage, false, data);
    expect(localStorage.getItem("self-messages")).toBeNull();
    expect(loadChat(localStorage).enabled).toBe(false);
  });
  it("delivers an overdue scheduled drawing once on the opposite side", () => {
    const result = deliverDue(data, 100);
    expect(result.messages[1]).toEqual({ ...data.scheduled[0], scheduled: true });
    expect(result.scheduled).toEqual([]);
    expect(deliverDue(result, 200).messages).toHaveLength(2);
  });
});