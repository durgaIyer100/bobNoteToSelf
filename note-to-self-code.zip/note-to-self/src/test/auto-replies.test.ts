import { describe, expect, it } from "vitest";
import { matchReply, type Rule } from "@/lib/auto-replies";

const rules: Rule[] = [
  { id: "text", keywords: ["sad"], message: "Breathe." },
  { id: "drawing", type: "drawing", keywords: [" Sad face "], message: "You got this." },
];

describe("auto-replies", () => {
  it("matches a chosen drawing category to its own message", () => {
    expect(matchReply(rules, "sad FACE", "drawing")?.message).toBe("You got this.");
  });
  it("does not trigger a drawing reply for another category", () => {
    expect(matchReply(rules, "happy face", "drawing")).toBeUndefined();
  });
  it("does not match text keywords against drawings", () => {
    expect(matchReply(rules, "sad", "drawing")).toBeUndefined();
  });
  it("preserves existing text keyword replies", () => {
    expect(matchReply(rules, "I feel sad today", "text")?.message).toBe("Breathe.");
  });
});