export type Rule = { id: string; keywords: string[]; message: string; type?: "text" | "drawing" };

export function matchReply(rules: Rule[], value: string, type: "text" | "drawing"): Rule | undefined {
  const lower = value.trim().toLowerCase();
  if (!lower) return undefined;
  return rules.find((rule) => (rule.type ?? "text") === type && rule.keywords.some((keyword) => {
    const key = keyword.trim().toLowerCase();
    return key && (type === "drawing" ? lower === key : lower.includes(key));
  }));
}