// On-device speech transcription. Audio is captured, decoded and transcribed
// entirely in the browser — nothing is ever uploaded or sent to any service.
// The Whisper model runs locally via WebGPU (when available) or WebAssembly.

let pipelinePromise: Promise<any> | null = null;

export function speechSupported(): boolean {
  return (
    typeof window !== "undefined" &&
    window.isSecureContext &&
    typeof (window as any).WebAssembly !== "undefined" &&
    !!navigator.mediaDevices?.getUserMedia &&
    typeof (window as any).MediaRecorder !== "undefined"
  );
}

async function loadPipeline() {
  const t = await import("@huggingface/transformers");
  let webgpu = false;
  try {
    webgpu = !!(navigator as any).gpu && !!(await (navigator as any).gpu.requestAdapter());
  } catch {}
  try {
    return await t.pipeline("automatic-speech-recognition", "onnx-community/whisper-tiny.en", {
      dtype: "q8",
      device: webgpu ? "webgpu" : "wasm",
    });
  } catch (e) {
    if (!webgpu) throw e;
    // WebGPU setup failed — fall back to WebAssembly, still fully on-device.
    return await t.pipeline("automatic-speech-recognition", "onnx-community/whisper-tiny.en", {
      dtype: "q8",
      device: "wasm",
    });
  }
}

function getTranscriber() {
  if (!pipelinePromise) {
    pipelinePromise = loadPipeline().catch((e) => {
      pipelinePromise = null;
      throw e;
    });
  }
  return pipelinePromise;
}

export async function transcribeBlob(blob: Blob): Promise<string> {
  const AC = (window as any).AudioContext || (window as any).webkitAudioContext;
  const ctx = new AC({ sampleRate: 16000 });
  const audio = await ctx.decodeAudioData(await blob.arrayBuffer());
  await ctx.close();

  let samples: Float32Array;
  if (audio.numberOfChannels === 1) {
    samples = audio.getChannelData(0);
  } else {
    const l = audio.getChannelData(0);
    const r = audio.getChannelData(1);
    samples = new Float32Array(l.length);
    for (let i = 0; i < l.length; i++) samples[i] = (l[i] + r[i]) / 2;
  }

  const transcriber = await getTranscriber();
  const out = await transcriber(samples, { chunk_length_s: 30, stride_length_s: 5 });
  return (out?.text ?? "").trim();
}
