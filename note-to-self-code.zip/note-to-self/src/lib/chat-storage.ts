export type Msg = { id: string; text: string; at: number; auto?: boolean; scheduled?: boolean; image?: string };
export type ChatData = { messages: Msg[]; scheduled: Msg[]; photo: string };
export const emptyChat = (): ChatData => ({ messages: [], scheduled: [], photo: "" });
const SAVE_KEY = "self-save-messages";
const DATA_KEY = "self-messages";

export function loadChat(storage: Storage): { enabled: boolean; data: ChatData } {
  if (storage.getItem(SAVE_KEY) !== "true") {
    storage.removeItem(DATA_KEY);
    return { enabled: false, data: emptyChat() };
  }
  try {
    const data = JSON.parse(storage.getItem(DATA_KEY) || "null");
    if (!data || !Array.isArray(data.messages) || !Array.isArray(data.scheduled) || typeof data.photo !== "string") {
      return { enabled: true, data: emptyChat() };
    }
    const valid = (m: Msg) => m && typeof m.id === "string" && typeof m.text === "string" && Number.isFinite(m.at) && (!m.image || m.image.startsWith("data:image/"));
    return { enabled: true, data: { messages: data.messages.filter(valid), scheduled: data.scheduled.filter(valid), photo: data.photo.startsWith("data:image/") ? data.photo : "" } };
  } catch { return { enabled: true, data: emptyChat() }; }
}

export function saveChat(storage: Storage, enabled: boolean, data: ChatData) {
  if (enabled) {
    storage.setItem(DATA_KEY, JSON.stringify(data));
    storage.setItem(SAVE_KEY, "true");
  } else {
    storage.removeItem(DATA_KEY);
    storage.removeItem(SAVE_KEY);
  }
}

export function deliverDue(data: ChatData, now: number): ChatData {
  const due = data.scheduled.filter((m) => m.at <= now);
  if (!due.length) return data;
  return { ...data, messages: [...data.messages, ...due.map((m) => ({ ...m, scheduled: true }))], scheduled: data.scheduled.filter((m) => m.at > now) };
}