# Running this code outside Lovable

## Setup

```bash
bun install     # or: npm install
bun run dev     # then open the printed local URL
bun run build   # production build
bun run test    # run the vitest suite
```

## The two homepage screenshots

`src/routes/index.tsx` imports `src/assets/chat-interface.png.asset.json` and
`src/assets/auto-replies.png.asset.json`. Those are pointer files: the real
images live in Lovable's asset storage, so the URLs inside them only resolve
while the app is served by Lovable.

Both images are included here as `src/assets/chat-interface.png` and
`src/assets/auto-replies.png`. To run anywhere, swap the imports in
`src/routes/index.tsx` from the `.asset.json` pointers to the plain image files
and use the imported URL directly, e.g.:

```ts
import chatInterface from "@/assets/chat-interface.png";
import autoReplies from "@/assets/auto-replies.png";
```

then use `src={chatInterface}` and `src={autoReplies}` on the `<img>` tags.

## Nothing else to configure

There is no backend, database, API key or account. Messages stay in the
browser: the "Save messages on this device" switch controls `localStorage`, and
the auto-reply rules are stored under `self-rules`. Speech-to-text downloads the
Whisper model into the browser once and transcribes locally — no audio leaves
the device.
